int main(){
  char *str;
  str="GTDGJ";
  *(str+1)='n';
  return 0;
}
